# HRJ Stock Brokers

A responsive Indian stock broker dashboard for tracking portfolio performance, allocation, NSE watchlist quotes, and Indian market news in INR.

## Run locally

Open `index.html` in a browser. No build step or package installation is required.

The watchlist starts with clearly labeled demo quotes for Reliance, TCS, HDFC Bank, Infosys, ICICI Bank, and SBI. To retrieve live NSE quotes, click **Connect data** and add a [Finnhub](https://finnhub.io) API key. The key is stored only in the browser's `localStorage`, and NSE-prefixed quotes are requested from Finnhub when **Refresh quotes** is clicked.
