const demoQuotes = [
  { symbol: "RELIANCE", name: "Reliance Industries", price: 2942.50, change: 2.42, color: "reliance" },
  { symbol: "TCS", name: "Tata Consultancy Services", price: 3850.25, change: 1.17, color: "tcs" },
  { symbol: "HDFCBANK", name: "HDFC Bank", price: 1682.40, change: 1.08, color: "hdfc" },
  { symbol: "INFY", name: "Infosys", price: 1510.75, change: -0.36, color: "infosys" },
  { symbol: "ICICIBANK", name: "ICICI Bank", price: 1128.60, change: -1.24, color: "icici" },
  { symbol: "SBIN", name: "State Bank of India", price: 835.90, change: 0.89, color: "sbi" }
];
let quotes = [...demoQuotes];
let refreshTimer;
const $ = (id) => document.getElementById(id);
const money = (value) => `₹${value.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const istFormatter = new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "full" });
const istTimeFormatter = new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });

function updateMarketStatus() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Kolkata", weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false }).formatToParts(now);
  const weekday = parts.find((part) => part.type === "weekday")?.value;
  const hour = Number(parts.find((part) => part.type === "hour")?.value);
  const minute = Number(parts.find((part) => part.type === "minute")?.value);
  const totalMinutes = hour * 60 + minute;
  const isWeekday = weekday !== "Sat" && weekday !== "Sun";
  const isOpen = isWeekday && totalMinutes >= 555 && totalMinutes < 930;
  $("marketDate").textContent = istFormatter.format(now);
  $("marketClock").textContent = `IST ${istTimeFormatter.format(now)}`;
  $("marketStatus").textContent = isOpen ? "NSE open" : "NSE closed";
  $("marketBadge").textContent = isOpen ? "NSE live market" : "NSE market closed";
  document.querySelector(".market-status i").style.background = isOpen ? "var(--green)" : "var(--orange)";
}

function renderWatchlist() {
  $("watchlistRows").innerHTML = quotes.map((quote) => {
    const positive = quote.change >= 0;
    return `<div class="watch-row">
      <div class="symbol-info"><span class="stock-logo ${quote.color || "apple"}">${quote.symbol.slice(0, 1)}</span><div><strong>${quote.symbol}</strong><small>${quote.name}</small></div></div>
      <span class="quote">${money(quote.price)}</span>
      <span class="quote-change ${positive ? "positive" : "negative"}">${positive ? "↗" : "↘"} ${positive ? "+" : ""}${quote.change.toFixed(2)}%</span>
      <button class="row-menu" aria-label="More options">•••</button>
    </div>`;
  }).join("");
}

function showToast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  window.setTimeout(() => $("toast").classList.remove("show"), 2800);
}

async function loadLiveQuotes() {
  const token = localStorage.getItem("hrj-finnhub-key");
  if (!token) {
    quotes = demoQuotes.map((quote) => ({ ...quote, price: +(quote.price * (1 + (Math.random() - .5) * .002)).toFixed(2) }));
    $("dataSource").textContent = "Demo NSE quotes · connect Finnhub for live prices";
    return;
  }
  const responses = await Promise.allSettled(quotes.map(async (quote) => {
    const response = await fetch(`https://finnhub.io/api/v1/quote?symbol=NSE%3A${encodeURIComponent(quote.symbol)}&token=${encodeURIComponent(token)}`);
    if (!response.ok) throw new Error(`Quote request failed for ${quote.symbol}`);
    const result = await response.json();
    if (!result.c) throw new Error(`No quote returned for ${quote.symbol}`);
    return { ...quote, price: result.c, change: result.dp ?? quote.change };
  }));
  const successfulQuotes = responses.filter((response) => response.status === "fulfilled").map((response) => response.value);
  if (!successfulQuotes.length) throw new Error("No NSE quotes returned");
  quotes = quotes.map((quote) => successfulQuotes.find((liveQuote) => liveQuote.symbol === quote.symbol) || quote);
  $("dataSource").textContent = "Live NSE quotes via Finnhub · auto-refreshes every 30 seconds";
}

async function refreshQuotes() {
  const button = $("refreshButton");
  button.disabled = true;
  button.innerHTML = '<span>↻</span> Updating...';
  try {
    await loadLiveQuotes();
    renderWatchlist();
    $("lastUpdated").textContent = istTimeFormatter.format(new Date());
    showToast(localStorage.getItem("hrj-finnhub-key") ? "Live NSE quotes updated" : "Add a Finnhub key to load live prices");
  } catch (error) {
    showToast("Could not load live quotes. Check your API key.");
  } finally {
    button.disabled = false;
    button.innerHTML = '<span>↻</span> Refresh quotes';
  }
}

function openDataDialog() {
  $("apiKeyInput").value = localStorage.getItem("hrj-finnhub-key") || "";
  $("dataDialog").showModal();
  $("apiKeyInput").focus();
}

$("refreshButton").addEventListener("click", refreshQuotes);
$("connectDataButton").addEventListener("click", openDataDialog);
$("settingsButton").addEventListener("click", openDataDialog);
$("dialogClose").addEventListener("click", () => $("dataDialog").close());
$("saveKeyButton").addEventListener("click", async () => {
  const key = $("apiKeyInput").value.trim();
  if (!key) {
    localStorage.removeItem("hrj-finnhub-key");
    $("dataDialog").close();
    window.clearInterval(refreshTimer);
    await refreshQuotes();
    window.clearInterval(refreshTimer);
    refreshTimer = window.setInterval(() => {
      if (localStorage.getItem("hrj-finnhub-key")) refreshQuotes();
    }, 30000);
    return;
  }
  localStorage.setItem("hrj-finnhub-key", key);
  $("dataDialog").close();
  await refreshQuotes();
});
$("depositButton").addEventListener("click", () => showToast("Deposit flow is ready to connect"));
$("addSymbolButton").addEventListener("click", () => {
  const symbol = window.prompt("Enter an NSE stock symbol to add");
  if (!symbol) return;
  const normalized = symbol.trim().toUpperCase();
  if (quotes.some((quote) => quote.symbol === normalized)) return showToast(`${normalized} is already on your watchlist`);
  quotes.push({ symbol: normalized, name: "Custom symbol", price: 0, change: 0, color: "apple" });
  renderWatchlist();
  updateMarketStatus();
  window.setInterval(updateMarketStatus, 1000);
  if (localStorage.getItem("hrj-finnhub-key")) {
    refreshQuotes();
    refreshTimer = window.setInterval(() => refreshQuotes(), 30000);
  }
  showToast(`${normalized} added — refresh to load its quote`);
});
$("searchInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && event.currentTarget.value.trim()) {
    $("addSymbolButton").click();
    event.currentTarget.value = "";
  }
});
document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    $("searchInput").focus();
  }
});

renderWatchlist();
